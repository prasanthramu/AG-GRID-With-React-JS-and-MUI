import React, { useEffect, useState } from "react";
import {
  ModeEditOutlineOutlined,
  DeleteOutlineOutlined,
  SaveOutlined,
  CancelOutlined,
} from "@mui/icons-material/";
import { Button, Stack } from "@mui/material";
import { deleteDataFromApi, editDataFromApi } from "../features/port/portSlice";
import { useDispatch } from "react-redux";

function CellRendererComp(params) {
  const [isEditGlobal, setIsEditGlobal] = useState(false);
  const dispatch = useDispatch();
  const [editSaveDeleteCancel, setEditSaveDeleteCancel] = useState(false);
  let row_index = params.rowIndex;
  const onHandleEdit = (data) => {
    // params.api.setFocusedCell(2, "portName");
    setEditSaveDeleteCancel(true);
    params.api.startEditingCell({
      rowIndex: row_index,
      colKey: "portName",
    });
  };
  const onHandleSave = () => {
    setEditSaveDeleteCancel(false);
    params.api.stopEditing();
    dispatch(editDataFromApi(params.data));
  };
  const onHandleDelete = (id) => {
    dispatch(deleteDataFromApi(id));
  };
  const onHandleCancel = () => {
    setEditSaveDeleteCancel(false);
    params.api.stopEditing();
  };

  return (
    <Stack spacing={2} direction="row" margin="10px">
      {!editSaveDeleteCancel ? (
        <Button
          style={{
            color: "#2c90e8",
            cursor: "pointer",
          }}
          onClick={() => {
            onHandleEdit(params.data);
          }}
          startIcon={<ModeEditOutlineOutlined />}
        />
      ) : (
        <Button startIcon={<SaveOutlined />} onClick={onHandleSave} />
      )}
      {!editSaveDeleteCancel ? (
        <Button
          style={{
            color: "#2c90e8",
            cursor: "pointer",
          }}
          onClick={() => {
            onHandleDelete(params.data.id);
          }}
          startIcon={<DeleteOutlineOutlined />}
        />
      ) : (
        <Button onClick={onHandleCancel} startIcon={<CancelOutlined />} />
      )}
    </Stack>
  );
}

export default CellRendererComp;
