import { configureStore } from "@reduxjs/toolkit";
import portSlice from "./port/portSlice";

export const store = configureStore({
  reducer: {
    portStore: portSlice,
  },
})

export default store