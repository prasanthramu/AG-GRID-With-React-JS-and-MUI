import React, { Component, lazy, Suspense, useState } from "react";
import { jsPanel } from "jspanel4/es6module/jspanel";
import "jspanel4/es6module/extensions/modal/jspanel.modal";
import "jspanel4/dist/jspanel.min.css";

// jsPanel default options
import panelOptions from "./panelOptions"
import PanelAction from "./panelAction";
import CreatePanel from "./createPanel";
import App from "../App";


function PanelHome() {
  const [state, setState] = useState({ panels: {} });
  const createJsPanel = (action, comp, modal = false) => {
    if (state.panels[action]) {
      return state.panels[action]["panel"].front(() => {
        state.panels[action]["panel"].resize({
          height: "auto",
        });
        state.panels[action]["panel"].reposition("center-top 0 20%");
      });
    }
    const options = {
      ...panelOptions,
      headerTitle: action,
      panelSize: {
        width: 1100,
        height: 500,
      },

      onclosed: () => {
        if (state.panels[action]) {
          delete state.panels[action];
          setState({ panels: { ...state.panels } });
        }
      },
    };

    //creating js panels
    const panel = modal
      ? jsPanel.modal.create(options)
      : jsPanel.create(options);

    setState({ panels: { ...state.panels, [action]: { panel, comp } } });
  };

  const renderJsPanlesInsidePortal = () => {
    const panels = state.panels;
    return Object.keys(panels).map((action) => {
      const jsPanel = panels[action].panel;
      const Comp = panels[action].comp;
      const node = document.getElementById(`${jsPanel.id}-node`);
      let counter = 0;
      if (!Comp) return null;
      return (
        <CreatePanel rootNode={node} key={jsPanel.id}>
          {Array.isArray(Comp) ? (
            Comp.map((C) => (
              <Suspense
                key={`${jsPanel.id}-${counter++}`}
                fallback={<div className="alert alert-info">Loading...</div>}
              >
                <C jsPanel={jsPanel} />
              </Suspense>
            ))
          ) : (
            <Suspense
              fallback={<div className="alert alert-info">Loading...</div>}
            >
              <Comp jsPanel={jsPanel} />
            </Suspense>
          )}
        </CreatePanel>
      );
    });
  };

  const jsPanels = Object.keys(state.panels);
  const actionButtonProps = {
    className: "btn btn-outline-primary ml-2 mb-2",
    handleClick: createJsPanel,
  };

  return (
    <>
      <div className="container-fluid">
        <div className="row bg-dark text-white shadow p-2">
          <div className="col-md-12">
            <h4 className="text-center">Port</h4>
          </div>
        </div>
        <div className="row justify-content-center mt-4">
          <div className="card">
            <div className="card-body">
              <PanelAction
                {...actionButtonProps}
                title="Port"
                comp={App}
              />
            </div>
          </div>
        </div>
        {jsPanels.length > 0 && renderJsPanlesInsidePortal()}
      </div>
    </>
  );
}

export default PanelHome;
