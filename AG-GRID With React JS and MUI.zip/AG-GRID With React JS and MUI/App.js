import "./App.css";
import PortHome from "./port/portHome";

function App() {
  return (
    <div style={{alignItems:"center"}}>
      <PortHome />
    </div>
  );
}

export default App;
