import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import axios from "axios";

const PORT_URL = `http://localhost:4000/port`;

const initialState = {
  isLoading: false,
  portData: [],
  message: "",
};

export const getDataFromApi = createAsyncThunk(
  `PORT_SLICE/getDataFromApi`,
  async () => {
    let res = await axios.get(PORT_URL);
    return res.data;
  }
);

export const addNewRowToApi = createAsyncThunk(
  `PORT_SLICE/addNewRowToApi`,
  async (newRow) => {
    let res = await axios.post(PORT_URL, newRow);
    return res.data;
  }
);

export const editDataFromApi = createAsyncThunk(
  `PORT_SLICE/editDataFromApi`,
  async (obj) => {
    let res = await axios.put(`${PORT_URL}/${obj.id}`, obj);
    return res.data;
  }
);

export const deleteDataFromApi = createAsyncThunk(``, async (id) => {
  let res = await axios.delete(`${PORT_URL}/${id}`);
  return res.data;
});

export const portSlice = createSlice({
  name: "PORT_SLICE",
  initialState,
  reducers: {
postNewData : (state, {payload}) => {
  state.portData = [...state.portData, payload]
}

  },
  extraReducers: (builder) => {
    // Get data from server
    builder.addCase(getDataFromApi.pending, (state, { payload }) => {
      state.isLoading = true;
      state.message = "Fetching data from server...";
    });
    builder.addCase(getDataFromApi.fulfilled, (state, { payload }) => {
      state.portData = payload;
      state.isLoading = false;
      state.message = "Data fetched from server successfully.";
    });
    builder.addCase(getDataFromApi.rejected, (state, { payload }) => {
      state.isLoading = false;
      state.message = "Data fetched failed.";
    });

    // Add new row to server
    builder.addCase(addNewRowToApi.pending, (state, { payload }) => {
      state.isLoading = true;
      state.message = "Adding new row to server...";
    });
    builder.addCase(addNewRowToApi.fulfilled, (state, { payload }) => {
      state.isLoading = false;
      state.message = "New row added to server successfully.";
    });
    builder.addCase(addNewRowToApi.rejected, (state, { payload }) => {
      state.isLoading = false;
      state.message = "Adding new row request rejected.";
    });

    // Delete data from server
    builder.addCase(deleteDataFromApi.pending, (state, { payload }) => {
      state.isLoading = true;
      state.message = "Deleting row from server...";
    });
    builder.addCase(deleteDataFromApi.fulfilled, (state, { payload }) => {
      state.isLoading = false;
      state.message = "Deleted Successfully.";
    });
    builder.addCase(deleteDataFromApi.rejected, (state, { payload }) => {
      state.isLoading = false;
      state.message = "Delete request rejected.";
    });

    // Edit data from server
    builder.addCase(editDataFromApi.pending, (state, { payload }) => {
      state.isLoading = true;
      state.message = "Editing data from server...";
    });
    builder.addCase(editDataFromApi.fulfilled, (state, { payload }) => {
      state.isLoading = false;
      state.message = "Edited Successfully.";
    });
    builder.addCase(editDataFromApi.rejected, (state, { payload }) => {
      state.isLoading = false;
      state.message = "Edit request rejected.";
    });
  },
});

export const { postNewData } = portSlice.actions
export const dataFromPortSlice = (state) => state;
export default portSlice.reducer;
