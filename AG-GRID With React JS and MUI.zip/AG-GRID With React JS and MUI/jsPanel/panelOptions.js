export default {
    theme: '#2c90e8',
    headerTitle: 'Port',
    position: {
        my: 'center',
        at: 'center',
    },
    contentSize: {
      width: `${Math.round(window.innerWidth / 1.2)}px`,
      height: `auto`
    },
    contentOverflow: 'auto',
    onwindowresize: false,
    headerControls: {
        minimize: 'remove',
        maximize:'remove',
        smallify: 'remove'
    },
    content: panel => {
      const div = document.createElement('div');
      const newId = `${panel.id}-node`;
      div.id = newId;
      panel.content.append(div);
    },
    callback: panel => {
      panel.content.style.padding = '10px';
      const maxHeight = window.innerHeight - (window.innerHeight * 1000) / 100;
      panel.content.style.maxHeight = `${maxHeight}px`;
      panel.content.style.maxWidth = `${window.innerWidth - 20}px`;
    },
    onclosed: () => {}
  };