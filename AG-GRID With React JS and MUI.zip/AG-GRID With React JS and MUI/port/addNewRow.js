import { Box, Stack, IconButton } from "@mui/material";
import {
  ModeEditOutlineOutlined,
  InsertDriveFileOutlined,
  SaveOutlined,
  CancelOutlined,
  DeleteOutlineOutlined,
  FindInPageOutlined,
  FileDownload,
  FileUpload,
} from "@mui/icons-material/";
import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { addNewRowToApi, deleteDataFromApi } from "../features/port/portSlice";
import { v4 } from "uuid";

function AddNewRow({
  globalParams,
  unique_id,
  newRow,
  setNewRow,
  onCellClickedParams,
  CellRendererState,
  setUniqueId,
  uniqueId,
  setEdit,
  edit,
}) {
  const dispatch = useDispatch();

  const addBtn = () => {
    const id = v4().slice(0, 4);
    setUniqueId(id);
    setNewRow(true);
    // setEdit(false)
    setTimeout(() => {
      globalParams.api.startEditingCell({
        rowIndex: 0,
        colKey: "portCode",
      });
    }, 1);
    let newRow = {
      id,
      portCode: "",
      portName: "",
      portColor: "",
      shortPortCode: "",
      portBaplieVersion: "",
    };
    globalParams.api.updateRowData({
      add: [newRow],
      addIndex: 0,
    });
    setTimeout(() => {
      dispatch(addNewRowToApi(newRow));
    }, 0);
  };

  const cancelBtn = () => {
    // console.log(globalParams);
    // console.log(globalParams.api.rowModel.nodeManager.rootNode.allLeafChildren);
    // console.log(globalParams.api.rowModel.nodeManager.rootNode.allLeafChildren.map(item => item.data)[0].id);
    // console.log(globalParams.api.rowModel.nodeManager.rootNode.allLeafChildren[0].data.id);
    const newId =
      globalParams.api.rowModel.nodeManager.rootNode.allLeafChildren.map(
        (item) => item.data
      )[0].id;
    setNewRow(false);
    setEdit(false);
    // console.log(edit);
    if (!edit) {
      if (newId) {
        dispatch(deleteDataFromApi(newId));
      }
      CellRendererState.api.applyTransaction({
        remove: [CellRendererState.node.data],
      });
    }
    setTimeout(() => {
      globalParams.api.stopEditing(true);
    }, 1);
  };

  return (
    <Box>
      <Stack
        justifyContent="flex-end"
        alignItems="center"
        spacing={-1}
        direction="row"
        margin="10px"
      >
        <IconButton disabled={newRow}>
          <InsertDriveFileOutlined
            style={{ color: !newRow ? "#2c90e8" : "#E73838" }}
            onClick={addBtn}
          />
        </IconButton>

        <IconButton disabled={true}>
          <SaveOutlined />
        </IconButton>

        <IconButton disabled={!newRow} onClick={cancelBtn}>
          <CancelOutlined style={{ color: newRow ? "#2c90e8" : "#E73838" }} />
        </IconButton>

        <IconButton
          disabled={edit}
          onClick={() => {
            // console.log(edit);
            setEdit(true);
            setNewRow(true);
          }}
        >
          <ModeEditOutlineOutlined
            style={{ color: !edit ? "#2c90e8" : "#E73838" }}
          />
        </IconButton>

        <IconButton disabled={true}>
          <FindInPageOutlined />
        </IconButton>

        <IconButton disabled={true}>
          <DeleteOutlineOutlined />
        </IconButton>

        <IconButton disabled={true}>
          <FileUpload />
        </IconButton>

        <IconButton disabled={true}>
          <FileDownload />
        </IconButton>
      </Stack>
    </Box>
  );
}

export default AddNewRow;
