import { SketchPicker } from "react-color";
import "./port.css";
import { AgGridReact } from "ag-grid-react";
import { useCallback, useEffect, useRef, useState } from "react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import AddNewRow from "./addNewRow";
import { Stack } from "@mui/material";
import axios from "axios";
import { useDispatch } from "react-redux";
import { v4 as uuid } from "uuid";
import { deleteDataFromApi, editDataFromApi } from "../features/port/portSlice";

// const unique_id = uuid().slice(0, 4);

let CellRendererState;
function PortHome() {
  const [colorState, setColorState] = useState(null);
  console.log(colorState);
  const [uniqueId, setUniqueId] = useState();
  const [globalParams, setGlobalParams] = useState();
  const [onCellClickedParams, setOnCellClickedParams] = useState();
  const [rowData, setRowData] = useState();
  const [newRow, setNewRow] = useState(false);
  const [edit, setEdit] = useState(false);
  let dispatch = useDispatch();
  let gridRef = useRef();

  const columnDefs = [
    {
      field: "portCode",
      filter: true,
      floatingFilter: true,
      sort: "asc",
      // editable: false,
    },
    {
      field: "portName",
      filter: true,
      floatingFilter: true,
    },
    {
      field: "portColor",
      colId: "portColor",
      cellRenderer: (params) => {
        console.log(newRow);
        let val;
        let changeVal = null
        const onChangeColor = (e) => {
          changeVal = e.target.value;
          console.log("changeVal",changeVal);
        };
        let data = params.api.gridOptionsWrapper.gridOptions.rowData;
        for (let i = newRow ? 1 : 0;  i < data.length; i++) {
          if (params.rowIndex === i) {
            let val = data[i].portColor;
            return (
              <input
                type="color"
                value={changeVal === null ? val : changeVal}
                variant="standard"
                style={{
                  border: "none",
                  backgroundColor: "white",
                  color: "black",
                  width: 25,
                  height: 25,
                }}
                onChange={onChangeColor}
              />
            );
          }
        }
      },
    },
    { field: "shortPortCode", filter: true, floatingFilter: true },
    { field: "portBaplieVersion", filter: true, floatingFilter: true },
    {
      headerName: "Action",
      cellRenderer: (params) => {
        // console.log(newRow);
        CellRendererState = params;
        const getEditingCells = params.api.getEditingCells();
        const currentRowEditing = getEditingCells.some((currentCell) => {
          return currentCell.rowIndex === params.node.rowIndex;
        });
        if (currentRowEditing) {
          return (
            <div>
              <button
                disabled={!edit && !newRow}
                className="editBtnStyle"
                data-action="update"
                onClick={() => {
                  setTimeout(() => {
                    dispatch(editDataFromApi(params.data));
                    setNewRow(false);
                    setEdit(false);
                  }, 0);
                }}
              >
                Update
                {!edit && !newRow && (
                  <span className="tooltip">Pls Enable Editor</span>
                )}
              </button>
              <button
                disabled={!edit && !newRow}
                className="deleteBtnStyle"
                data-action="cancel"
                onClick={() => {
                  setNewRow(false);
                  setEdit(false);
                }}
              >
                Cancel
                {!edit && !newRow && (
                  <span className="tooltip">Pls Enable Editor</span>
                )}
              </button>
            </div>
          );
        } else {
          return (
            <div>
              <button
                className="editBtnStyle"
                data-action="edit"
                disabled={!edit && !newRow}
              >
                Edit
                {!edit && !newRow && (
                  <span className="tooltip">Pls Enable Editor</span>
                )}
              </button>
              <button
                disabled={!edit && !newRow}
                className="deleteBtnStyle"
                data-action="delete"
                onClick={() => {
                  dispatch(deleteDataFromApi(params.data.id));
                }}
              >
                Delete
                {!edit && !newRow && (
                  <span className="tooltip">Pls Enable Editor</span>
                )}
              </button>
            </div>
          );
        }
      },
      editable: false,
      colId: "action",
    },
  ];

  const defaultColDef = {
    flex: 1,
    editable: true,
    sortable: true,
    cellClassRules: {
      "ag-green": "x",
    },
    // stopEditingWhenCellsLoseFocus: true,
  };

  const onGridReady = useCallback(async (params) => {
    setGlobalParams(params);
    let res = await axios.get(`http://localhost:4000/port`);
    return setRowData(res.data);
  }, []);

  const onCellClicked = (params) => {
    // setOnCellClickedParams(params);
    const columnId = params.column.colId;
    if (columnId === "action" && params.event.target.dataset.action) {
      const columnAction = params.event.target.dataset.action;

      if (columnAction === "edit") {
        params.api.startEditingCell({
          rowIndex: params.node.rowIndex,
          colKey: params.columnApi.getDisplayedCenterColumns()[0].colId,
        });
      }
      if (columnAction === "delete") {
        params.api.applyTransaction({
          remove: [params.node.data],
        });
      }
      if (columnAction === "update") {
        params.api.stopEditing(false);
      }
      if (columnAction === "cancel") {
        if (params.rowIndex === 0 && uniqueId === params.node.data.id) {
          params.api.applyTransaction({
            remove: [params.node.data],
          });
          dispatch(deleteDataFromApi(params.node.data.id));
        }
        params.api.stopEditing(true);
      }
    }
  };

  const onRowEditingStarted = (params) => {
    params.api.refreshCells({
      columns: ["action"],
      rowNodes: [params.node],
      force: true,
    });
  };

  const onRowEditingStopped = (params) => {
    params.api.refreshCells({
      columns: ["action"],
      rowNodes: [params.node],
      force: true,
    });
  };

  return (
    <div>
      <Stack
        justifyContent="flex-end"
        alignItems="center"
        direction="row"
        spacing={0.5}
      >
        <AddNewRow
          gridRef={gridRef}
          globalParams={globalParams}
          newRow={newRow}
          setNewRow={setNewRow}
          onCellClickedParams={onCellClickedParams}
          CellRendererState={CellRendererState}
          uniqueId={uniqueId}
          setUniqueId={setUniqueId}
          edit={edit}
          setEdit={setEdit}
        />
      </Stack>
      <div className="ag-theme-alpine" style={{ width: "auto" }}>
        <AgGridReact
          onGridReady={onGridReady}
          ref={gridRef}
          rowData={rowData}
          // rowData={selector.portData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          domLayout={"autoHeight"}
          suppressMenuHide={true} // header menu icons visibilities
          editType={"fullRow"}
          onCellClicked={onCellClicked}
          onRowEditingStarted={onRowEditingStarted}
        />
      </div>
    </div>
  );
}

export default PortHome;
